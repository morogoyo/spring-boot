package com.Trident.Repositories;


import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import com.Trident.Data.EmailUser;

public interface EmailUserRepository extends CassandraRepository<EmailUser> {

	
	@Query("select * from email_users where email = ?0")
		EmailUser findByEmail(String email);
}

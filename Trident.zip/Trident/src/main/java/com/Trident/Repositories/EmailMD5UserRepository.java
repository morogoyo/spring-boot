package com.Trident.Repositories;


import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import com.Trident.Data.EmailMD5User;

public interface EmailMD5UserRepository extends CassandraRepository<EmailMD5User> {

	
	@Query("select * from email_md5_users where email_md5 = ?0")
		EmailMD5User findByEmailMD5(String email_md5);
}

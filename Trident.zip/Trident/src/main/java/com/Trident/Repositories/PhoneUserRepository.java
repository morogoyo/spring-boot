package com.Trident.Repositories;


import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import com.Trident.Data.PhoneUser;

public interface PhoneUserRepository extends CassandraRepository<PhoneUser> {

	
	@Query("select * from phone_users where phone = ?0")
		PhoneUser findByPhone(String phone);
}

package com.Trident.Repositories;

import java.util.UUID;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import com.Trident.Data.User;

public interface UserRepository extends CassandraRepository<User> {

	@Query("select * from users where user_id = ?0")
	User findByUUID(UUID user_id);

}

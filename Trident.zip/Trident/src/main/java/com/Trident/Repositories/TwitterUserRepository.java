package com.Trident.Repositories;


import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import com.Trident.Data.TwitterUser;

public interface TwitterUserRepository extends CassandraRepository<TwitterUser> {

	
	@Query("select * from twitter_users where twitter = ?0")
		TwitterUser findByTwitter(String twitter);
}

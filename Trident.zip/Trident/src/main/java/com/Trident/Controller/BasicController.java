package com.Trident.Controller;

import java.io.IOException;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Trident.Data.*;
import com.Trident.Repositories.*;
import com.datastax.driver.core.utils.UUIDs;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fullcontact.api.libs.fullcontact4j.FullContact;
import com.fullcontact.api.libs.fullcontact4j.FullContactException;
import com.fullcontact.api.libs.fullcontact4j.http.person.PersonRequest;
import com.fullcontact.api.libs.fullcontact4j.http.person.PersonResponse;

@RestController
public class BasicController {
	
	@Autowired
	private UserRepository usersRepo;
	
	@Autowired
	private EmailUserRepository emailUsersRepo;
	
	@Autowired
	private EmailMD5UserRepository emailMD5UsersRepo;
	
	@Autowired
	private TwitterUserRepository twitterUsersRepo;
	
	@Autowired
	private PhoneUserRepository phoneUsersRepo;

	//class to handle the requests to the FC person API
	@RequestMapping(path = "/Person", method = RequestMethod.GET, produces = "application/json")
	public PersonResponse returnObject(@RequestParam(value="email",defaultValue = "") String email,
										@RequestParam(value="email_md5",defaultValue = "") String email_md5,
										@RequestParam(value="twitter",defaultValue = "") String twitter,
										@RequestParam(value="phone",defaultValue = "") String phone) throws FullContactException, IOException{
		
		String cachedUser = getCachedUser(email, email_md5, twitter, phone);

		//if person wasn't found in the cache
		//get new person and store in cache
		if(cachedUser.equals("")){
			return getNewUser(email, email_md5, twitter, phone);
		}
		else{
			ObjectMapper objectMapper = new ObjectMapper();
	        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
	        objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
            return objectMapper.readValue(cachedUser, PersonResponse.class);
		}

	}
	
	/*search the cassandra cache for a user that already exists
	  return the related data if found
	  otherwise return empty string*/
	private String getCachedUser(String email, String email_md5, String twitter, String phone){
		if(!email.equals("")){
			//get the user id from the database if it exists
			EmailUser emailUser = emailUsersRepo.findByEmail(email);
			//if user id exists, get data based on user id
			if(emailUser != null){
				User userData = usersRepo.findByUUID(emailUser.getUser_id());
				return userData.getValue();
			}
		}
		else if(!email_md5.equals("")){
			//get the user id from the database if it exists
			EmailMD5User emailMD5User = emailMD5UsersRepo.findByEmailMD5(email_md5);
			//if user id exists, get data based on user id
			if(emailMD5User != null){
				User userData = usersRepo.findByUUID(emailMD5User.getUser_id());
				return userData.getValue();
			}
	   	}
		else if(!twitter.equals("")){
			//get the user id from the database if it exists
			TwitterUser twitterUser = twitterUsersRepo.findByTwitter(twitter);
			//if user id exists, get data based on user id
			if(twitterUser != null){
				User userData = usersRepo.findByUUID(twitterUser.getUser_id());
				return userData.getValue();
			}
	   	}
	   	else if(!phone.equals("")){
			//get the user id from the database if it exists
			PhoneUser phoneUser = phoneUsersRepo.findByPhone(phone);
			//if user id exists, get data based on user id
			if(phoneUser != null){
				User userData = usersRepo.findByUUID(phoneUser.getUser_id());
				return userData.getValue();
			}
	   	}
		
		return "";
	}
	
	private PersonResponse getNewUser(String email, String email_md5, String twitter, String phone) throws JsonProcessingException{
		ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		
		PersonResponse personResponse = getFCPerson(email, email_md5, twitter, phone); 	        
        if(personResponse == null){
        	return null;
        }
        
		String personAsString = objectMapper.writeValueAsString(personResponse);
   		
   		//insert user into database
   		UUID uuid = UUIDs.timeBased();
        final User user = new User(personAsString,uuid);
        usersRepo.save(user);
        
        //insert the newly formed uuid into the DB based on which identifier was passed in
		if(!email.equals("")){
			final EmailUser emailUser = new EmailUser(email, uuid);
			emailUsersRepo.save(emailUser);
		}
		else if(!email_md5.equals("")){
			final EmailMD5User emailMD5User = new EmailMD5User(email_md5, uuid);
			emailMD5UsersRepo.save(emailMD5User);
	   	}
		else if(!twitter.equals("")){
			final TwitterUser twitterUser = new TwitterUser(twitter, uuid);
			twitterUsersRepo.save(twitterUser);
	   	}
	   	else if(!phone.equals("")){
			final PhoneUser phoneUser = new PhoneUser(phone, uuid);
			phoneUsersRepo.save(phoneUser);
	   	}
		
		return personResponse;
	}
	
	//reach out to full contact to get a person's data
	private PersonResponse getFCPerson(String email, String email_md5, String twitter, String phone){
	   	FullContact fullContact = FullContact.withApiKey("36e7f17472338e19").build();
	   	PersonRequest personRequest;
		PersonResponse personResponse = null;
	   	
		//figure out if something other than email was used
		if(!email.equals("")){
	   		personRequest = fullContact.buildPersonRequest().email(email).macromeasures(true).build();
		}
		else if(!email_md5.equals("")){
	   		personRequest = fullContact.buildPersonRequest().emailMd5(email_md5).macromeasures(true).build();
	   	}
		else if(!twitter.equals("")){
	   		personRequest = fullContact.buildPersonRequest().twitterName(twitter).macromeasures(true).build();
	   	}
	   	else if(!phone.equals("")){
	   		personRequest = fullContact.buildPersonRequest().phone(phone).macromeasures(true).build();
	   	}
	   	else{
	   		return null;
	   	}
			
		//try the request
		try{
	   		personResponse= fullContact.sendRequest(personRequest);
		}
		catch(FullContactException e){
			System.err.println(e.getMessage());
		}
		return personResponse;
	}
}

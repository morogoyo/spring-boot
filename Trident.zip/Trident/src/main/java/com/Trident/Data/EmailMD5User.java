package com.Trident.Data;

import java.util.UUID;

import org.springframework.data.cassandra.mapping.Column;
import org.springframework.data.cassandra.mapping.PrimaryKey;
import org.springframework.data.cassandra.mapping.Table;


@Table(value = "email_md5_users")
public class EmailMD5User {

	@Column
	private String email_md5;
	@PrimaryKey("user_id")
	private UUID user_id;
	
	public EmailMD5User(String email_md5, UUID user_id) {
		this.email_md5 = email_md5;
		this.user_id = user_id;
	}

	public String getEmailMD5() {
		return email_md5;
	}

	public void setEmailMD5(String email_md5) {
		this.email_md5 = email_md5;
	}

	public UUID getUser_id() {
		return user_id;
	}

	public void setUser_id(UUID user_id) {
		this.user_id = user_id;
	}
	
	
}
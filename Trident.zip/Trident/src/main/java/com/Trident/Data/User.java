package com.Trident.Data;

import java.util.UUID;

import org.springframework.data.cassandra.mapping.Column;
import org.springframework.data.cassandra.mapping.PrimaryKey;
import org.springframework.data.cassandra.mapping.Table;


@Table(value = "users")
public class User {

	@Column
	private String value;
	@PrimaryKey("user_id")
	private UUID user_id;
	
	public User(String value, UUID user_id) {
		this.value = value;
		this.user_id = user_id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public UUID getUser_id() {
		return user_id;
	}

	public void setUser_id(UUID user_id) {
		this.user_id = user_id;
	}
	
	
}

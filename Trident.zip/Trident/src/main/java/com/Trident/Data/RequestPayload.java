package com.Trident.Data;

import javax.persistence.Entity;

@Entity
public class RequestPayload {

	private String email;
	private String email_md5;
	private String twitter;
	private String phone;
	

	public RequestPayload(String email, String email_md5, String twitter, String phone) {
		this.email = email;
		this.email_md5 = email_md5;
		this.twitter = twitter;
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEmail_md5() {
		return email_md5;
	}
	public void setEmail_md5(String email_md5) {
		this.email_md5 = email_md5;
	}
	public String getTwitter() {
		return twitter;
	}
	public void setTwitter(String twitter) {
		this.twitter = twitter;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
}

package com.Trident.Data;

import java.util.UUID;

import org.springframework.data.cassandra.mapping.Column;
import org.springframework.data.cassandra.mapping.PrimaryKey;
import org.springframework.data.cassandra.mapping.Table;


@Table(value = "twitter_users")
public class TwitterUser {

	@Column
	private String twitter;
	@PrimaryKey("user_id")
	private UUID user_id;
	
	public TwitterUser(String twitter, UUID user_id) {
		this.twitter = twitter;
		this.user_id = user_id;
	}

	public String gettwitter() {
		return twitter;
	}

	public void settwitter(String twitter) {
		this.twitter = twitter;
	}

	public UUID getUser_id() {
		return user_id;
	}

	public void setUser_id(UUID user_id) {
		this.user_id = user_id;
	}
	
	
}
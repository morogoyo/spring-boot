package com.Trident.Data;

import java.util.UUID;

import org.springframework.data.cassandra.mapping.Column;
import org.springframework.data.cassandra.mapping.PrimaryKey;
import org.springframework.data.cassandra.mapping.Table;


@Table(value = "phone_users")
public class PhoneUser {

	@Column
	private String phone;
	@PrimaryKey("user_id")
	private UUID user_id;
	
	public PhoneUser(String phone, UUID user_id) {
		this.phone = phone;
		this.user_id = user_id;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public UUID getUser_id() {
		return user_id;
	}

	public void setUser_id(UUID user_id) {
		this.user_id = user_id;
	}
	
	
}
package com.Trident.Data;

import java.util.UUID;

import org.springframework.data.cassandra.mapping.Column;
import org.springframework.data.cassandra.mapping.PrimaryKey;
import org.springframework.data.cassandra.mapping.Table;


@Table(value = "email_users")
public class EmailUser {

	@Column
	private String email;
	@PrimaryKey("user_id")
	private UUID user_id;
	
	public EmailUser(String email, UUID user_id) {
		this.email = email;
		this.user_id = user_id;
	}

	public String getemail() {
		return email;
	}

	public void setemail(String email) {
		this.email = email;
	}

	public UUID getUser_id() {
		return user_id;
	}

	public void setUser_id(UUID user_id) {
		this.user_id = user_id;
	}
	
	
}